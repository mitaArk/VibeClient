package ru.expensive.api.event.events;

public interface Event {

}
