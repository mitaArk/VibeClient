package ru.expensive.api.event.types;

public class EventType {

    public static final byte
            PRE = 0,
            ON = 1,
            POST = 2,
            SEND = 3,
            RECIEVE = 4;

}
