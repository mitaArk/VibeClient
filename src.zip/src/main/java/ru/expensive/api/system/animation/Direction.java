package ru.expensive.api.system.animation;

public enum Direction {
    FORWARDS,
    BACKWARDS
}
