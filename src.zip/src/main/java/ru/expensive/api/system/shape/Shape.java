package ru.expensive.api.system.shape;

public interface Shape {
    void render(ShapeProperties shapeProperties);
}
