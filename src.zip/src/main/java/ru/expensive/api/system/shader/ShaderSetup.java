package ru.expensive.api.system.shader;

public interface ShaderSetup {
    void setup();
}
