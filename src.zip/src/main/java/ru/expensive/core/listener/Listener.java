package ru.expensive.core.listener;

import ru.expensive.common.QuickLogger;

public interface Listener extends QuickLogger {
}
