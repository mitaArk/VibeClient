package ru.expensive.common;

public class SelectedProtocol {
    public static String version = "1.20.1";
}
