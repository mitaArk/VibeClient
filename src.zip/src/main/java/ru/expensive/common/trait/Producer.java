package ru.expensive.common.trait;

public interface Producer<T> {
    T create();
}