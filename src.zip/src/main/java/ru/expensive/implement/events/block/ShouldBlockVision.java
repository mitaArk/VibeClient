package ru.expensive.implement.events.block;

import ru.expensive.api.event.events.callables.EventCancellable;

public class ShouldBlockVision extends EventCancellable {
}
