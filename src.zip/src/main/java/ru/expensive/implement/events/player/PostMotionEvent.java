package ru.expensive.implement.events.player;

import ru.expensive.api.event.events.callables.EventCancellable;

public class PostMotionEvent extends EventCancellable {
}
