package ru.expensive.implement.events.block;

import ru.expensive.api.event.events.callables.EventCancellable;

public class PushBlockEvent extends EventCancellable {
}
