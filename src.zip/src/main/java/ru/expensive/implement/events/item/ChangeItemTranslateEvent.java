package ru.expensive.implement.events.item;

import ru.expensive.api.event.events.callables.EventCancellable;

public class ChangeItemTranslateEvent extends EventCancellable {

}
