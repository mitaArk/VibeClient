package ru.expensive.implement.events.player;

import ru.expensive.api.event.events.Event;

public class PostTickEvent implements Event {
}
