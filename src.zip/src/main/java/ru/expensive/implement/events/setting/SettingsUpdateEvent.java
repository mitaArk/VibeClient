package ru.expensive.implement.events.setting;

import ru.expensive.api.event.events.Event;

public class SettingsUpdateEvent implements Event {
}
