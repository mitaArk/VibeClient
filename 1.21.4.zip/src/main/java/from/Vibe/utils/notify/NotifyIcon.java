package from.Vibe.utils.notify;

public record NotifyIcon(String icon) {
}