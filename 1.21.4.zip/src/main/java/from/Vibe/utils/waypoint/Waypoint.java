package from.Vibe.utils.waypoint;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor @Getter
public class Waypoint {
	private String name;
	private double x, z;
}