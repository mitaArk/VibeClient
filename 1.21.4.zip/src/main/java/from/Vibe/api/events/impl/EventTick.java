package from.Vibe.api.events.impl;

import from.Vibe.api.events.Event;

public class EventTick extends Event {
}