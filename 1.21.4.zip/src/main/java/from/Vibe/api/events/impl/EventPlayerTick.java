package from.Vibe.api.events.impl;

import from.Vibe.api.events.Event;

public class EventPlayerTick extends Event {
}