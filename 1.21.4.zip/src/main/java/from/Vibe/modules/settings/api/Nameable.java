package from.Vibe.modules.settings.api;

public interface Nameable {
    String getName();
}