package from.Vibe.modules.impl.combat;

import from.Vibe.modules.api.Category;
import from.Vibe.modules.api.Module;

public class NoFriendDamage extends Module {

    public NoFriendDamage() {
        super("NoFriendDamage", Category.Combat);
    }
}