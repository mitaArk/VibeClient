package from.Vibe.modules.impl.misc;

import from.Vibe.modules.api.Category;
import from.Vibe.modules.api.Module;

public class ItemHelper extends Module {

    public ItemHelper() {
        super("ItemHelper", Category.Misc);
    }
}