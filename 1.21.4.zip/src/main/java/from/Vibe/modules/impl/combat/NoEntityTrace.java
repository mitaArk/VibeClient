package from.Vibe.modules.impl.combat;

import from.Vibe.modules.api.Category;
import from.Vibe.modules.api.Module;

public class NoEntityTrace extends Module {

    public NoEntityTrace() {
        super("NoEntityTrace", Category.Combat);
    }
}