package from.Vibe.modules.impl.movement;

import from.Vibe.modules.api.Category;
import from.Vibe.modules.api.Module;

public class MoveFix extends Module {

    public MoveFix() {
        super("MoveFix", Category.Movement);
    }
}