package from.Vibe.modules.impl.render;

import from.Vibe.modules.api.Category;
import from.Vibe.modules.api.Module;

public class Fullbright extends Module {

    public Fullbright() {
        super("Fullbright", Category.Render);
    }
}